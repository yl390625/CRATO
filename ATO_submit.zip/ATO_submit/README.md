# A Near-Optimal Control Policy for Data-driven Assemble-to-order Systems

This repository contains the implementation of *A Near-Optimal Control Policy for Data-driven
Assemble-to-order Systems*.

## Project Structure

*   **`benchmark/`**: Contains benchmark algorithms.
    *   `main_Song.py`: Implementation of Song's Newsvendor heuristic and PRP allocation rule.
    *   `main_N_system_opt.py`: Optimization for the "N-system" configuration.
*   **`data_generate/`**: Scripts and data for demand generation.
    *   `generator/`: Scripts to generate demand samples.
    *   `demand_sample/`: Stores the generated `.npy` files.
*   **`dp/`**: Dynamic programming implementation for policy evaluation and training.
    *   `eval_dp.py`: Evaluation of dynamic programming policies.
    *   `train_dp.py`: Training dynamic programming policies.
*   **`elegantrl/`**: A DRL library simplified and adapted for this project (contains agents, environments, training loops).
    *   `agents/ATO/`: ATO specific agent implementations.
    *   `envs/ATO_env/`: ATO environment definitions (`ATOFixedLTCATrain`, `ATOFixedLTCATest`) and configuration.
*   **`evals/`**: Scripts for evaluating trained agents.
    *   `eval_TD3.py`: Evaluates TD3 agents.
    *   `eval_CTD3.py`: Evaluates CTD3 agents.
*   **`exp_data/`**: Configuration files (`.xlsx`) defining system parameters (costs, structure, lead times) for different experiments (N-system, PC-system, Large-system).
*   **`run_RL/`**: Entry points for training RL agents.
    *   `run_TD3.py`, `run_CTD3.py`: Scripts to start training.
    *   `models/`: Saved model checkpoints.

## Prerequisites

Ensure you have Python 3.x installed. You will need the following libraries:

```bash
pip install numpy pandas gym scipy gurobipy tqdm torch openpyxl
```

**Note:** `gurobipy` requires a Gurobi license (academic or commercial) to solve the optimization models in the benchmarks.

## Experiment Configurations

The system parameters are defined in Excel files in `exp_data/`:
*   `experimentN.xlsx`: N-system configuration.
*   `experimentPC.xlsx`: PC-system configuration.
*   `experimentLarge.xlsx`: A larger system configuration.
*   `experimentNCorr.xlsx`: N-system with correlated demand.

## Usage

### 1. Training RL Agents

To train a (C)TD3 agent, use the `run_RL/run_(C)TD3.py` script. You can specify the experiment name and other parameters.

**Arguments:**
*   `--exp_name`: Name of the experiment configuration (default: `experimentN`). Options: `experimentN`, `experimentPC`, `experimentLarge`, `experimentNCorr`.
*   `--sample_num`: Number of demand samples used for training (default: `10`).
*   `--visible_gpu`: GPU ID to use (default: `0`).

**Example:**

```bash
cd run_RL
python run_TD3.py --exp_name experimentN --sample_num 10
```

This will save the trained model in `run_RL/models/`.

### 2. Evaluating RL Agents

To evaluate a trained model, use `evals/eval_(C)TD3.py`.

**Arguments:**
*   `--exp_name`: Name of the experiment configuration.
*   `--model_names`: List of model names (folder names in `run_RL/models/`) to evaluate.
*   `--time_horizon`: Simulation steps (default: `10000`).
*   `--replication`: Number of replications (default: `100`).

**Example:**

```bash
cd evals
python eval_TD3.py --exp_name experimentN --model_names example_model --time_horizon 10000 --replication 100
```

Results will be saved in `evals/results/`. 

**Note:** The order/production/BO/IO_max parameter need to be set the same as during training.

### 3. Running Benchmarks

To run the heuristic benchmarks (NV-PRP), use `benchmark/main_Song.py`.

**Arguments:**
*   `--config_name`: Experiment configuration name (default: `experimentN`).
*   `--sample_num`: Number of demand samples (default: `10`).
*   `--replication`: Number of replications (default: `100`).

**Example:**

```bash
cd benchmark
python main_Song.py --config_name experimentN --sample_num 10
```

To run the N-system optimization benchmark, use `benchmark/main_N_system_opt.py`.
```bash
cd benchmark
python main_N_system_opt.py
```

### 5. (Optional) Data Generation

Before running experiments, generate the demand data. Run the scripts from the `data_generate` directory so that data is saved in the correct location (`data_generate/demand_sample/`).

```bash
cd data_generate
python generator/poisson_generator.py
# Run other generators as needed (e.g., generator/uniform_generator.py)
```